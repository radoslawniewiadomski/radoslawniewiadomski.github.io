package org.infomus.android.sensor_to_osc_template;


import org.infomus.android.sensor_to_osc_template.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.hardware.SensorManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ToggleButton;

public class ConfigurationActivity extends Activity {
	
	// strings tags
	private static final String TAG = "ConfigurationActivity";

	public static final String NETWORK_ADDRESS = "network_address";
	public static final String NETWORK_PORT = "network_port";
	public static final String DEVICE_IDENTIFIER = "device_identifier";
	public static final String TARGET_FPS = "target_fps";
	
	public static final String DISABLE_SCREEN_SAVER = "disable_screen_saver";
	
	public static final String ACCELEROMETER_STATUS = "accelerometer";
	public static final String GYROSCOPE_STATUS = "gyroscope";
	public static final String PROXIMITY_STATUS = "proximity";
	
	public static final String LINEAR_ACCELERATION_STATUS = "linear_acceleration";
	public static final String GRAVITY_STATUS = "gravity";
	public static final String ROTATION_VECTOR_STATUS = "rotation_vector";
	
	public static final String MAGNETIC_FIELD_STATUS = "magnetic_field";
	public static final String PRESSURE_STATUS = "pressure";
	public static final String LIGHT_STATUS = "light";
	
	public static final String AMBIENT_TEMPERATURE_STATUS = "temperature";
	public static final String HUMIDITY_STATUS = "humidity";
	// NOTE: if you add a sensor here, remember to update the map in MainActivity::onCreate
	
	
	Intent resultData = new Intent();

	 /**
     * OnCreate method overrides base class method
     * @param  savedInstanceState  the bundle passed by the main activity    
     */   
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_configuration);
        
        Intent intent = getIntent();
        //widgets initialization
        initializeTextField( intent, NETWORK_ADDRESS, R.id.receiverAddressText);
        initializeNumericField( intent, NETWORK_PORT, R.id.receiverPort, 10000 );
        initializeNumericField( intent, DEVICE_IDENTIFIER, R.id.deviceIdentifierText, 1 );
        initalizeSpinner(intent,TARGET_FPS,R.id.targetFPSSpinner,SensorManager.SENSOR_DELAY_GAME);        
        
        initializeToggleButton( intent, DISABLE_SCREEN_SAVER, R.id.toggleDisableScreenSaverButton );
        
        /*
         * ADD NEW BUTTONS HERE!!
         * */
           
        onConfigurationChanged();
    }
    
    /**
     * OnCreateOptionsMenu method overrides base class method
     * @param  menu the options menu    
     */   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_configuration, menu);
        return true;
    }
    
    /**
     * OnPause method overrides base class member     
     */   
    @Override
    protected void onPause() {
    	super.onPause();
    }
    
    /**
     * initializes a toggle button
     * @param  intent  
     * @param  name the name of the widget
     * @param  buttonId the id of the target button     
     */    
    private void initializeToggleButton( Intent intent, final String name, int buttonId ) {
    	boolean status = intent.getBooleanExtra( name, false );
        final ToggleButton toggleButton = (ToggleButton)findViewById( buttonId );
        toggleButton.setChecked( status );
        toggleButton.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
            	onToggleButtonChanged( name, toggleButton, isChecked );
            }
        });
        onToggleButtonChanged( name, toggleButton, status );
        
    }
       
    /**
     * initializes a text field widget
     * @param  intent  
     * @param  name the name of the widget
     * @param  viewId the id of the target widget     
     */
    private void initializeTextField( Intent intent, final String name, int viewId ) {
    	String text = intent.getStringExtra(name);
        final EditText editText = (EditText)findViewById(viewId);
        editText.setText(text);
        editText.addTextChangedListener( new TextWatcher() {
					public void afterTextChanged(Editable s) {
						onTextFieldChanged( name, editText );
					}
		
					public void beforeTextChanged(CharSequence s, int start, int count,
							int after) {
					}
		
					public void onTextChanged(CharSequence s, int start, int before,
							int count) {
					}
			
				}
			);
        onTextFieldChanged( name, editText );
    }
        
    /**
     * initializes a numeric field widget
     * @param  intent  
     * @param  name the name of the widget
     * @param  viewId the id of the target widget  
     * @param  defaultVaue the default assigned value    
     */
    private void initializeNumericField( Intent intent, final String name, int viewId, int defaultValue ) {
    	int value = intent.getIntExtra( name, defaultValue );
        final EditText editText = (EditText)findViewById( viewId );
        editText.setText( String.valueOf(value) );
        editText.addTextChangedListener( new TextWatcher() {
					public void afterTextChanged(Editable s) {
						onNumericFieldChanged( name, editText );
					}
		
					public void beforeTextChanged(CharSequence s, int start, int count,
							int after) {
					}
		
					public void onTextChanged(CharSequence s, int start, int before,
							int count) {
					}
			
				}
			);
        onNumericFieldChanged( name, editText );
    }
        
    /**
     * initializes a spinner field widget
     * @param  intent  an absolute URL giving the base location of the image
     * @param  name the name of the widget
     * @param  viewId  buttonId the id of the target widget
     * @param  defaultVaue the default assigned value     
     */
    private void initalizeSpinner( Intent intent, final String name, int viewId, int defaultValue ) {
    	int value = intent.getIntExtra( name, defaultValue );
    	final Spinner spinner = (Spinner) findViewById(viewId);
    	// Create an ArrayAdapter using the string array and a default spinner layout
    	ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
    	        R.array.fps_array, android.R.layout.simple_spinner_item);
    	// Specify the layout to use when the list of choices appears
    	adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
    	// Apply the adapter to the spinner
    	spinner.setAdapter(adapter);
    	spinner.setSelection(value); 
    	spinner.setOnItemSelectedListener(
    			new AdapterView.OnItemSelectedListener() {

					public void onItemSelected(AdapterView<?> arg0, View arg1,
							int pos, long id) {
						onSpinnerChanged(name,spinner,pos);
						
					}

					public void onNothingSelected(AdapterView<?> arg0) {						
						
					}}
    			);
    	onSpinnerChanged(name,spinner,value);
    }

    /**
     * handler of textFiledChanged event
     * @param  name the name of the widget     
     * @param  editText the new text value     
     */
    public void onTextFieldChanged( String name, EditText editText ) {
    	String text = editText.getText().toString();
    	resultData.putExtra( name, text );
    	onConfigurationChanged();
    }
    
    /**
     * handler of NumericFieldChanged event
     * @param  name the name of the widget     
     * @param  editText the new value     
     */
    public void onNumericFieldChanged( String name, EditText editText ) {
    	try {
    		int value = Integer.parseInt( editText.getText().toString() );
    		resultData.putExtra( name, value );
    		onConfigurationChanged();
    	}
    	catch( NumberFormatException e ) {
    		Log.v( TAG, e.getMessage() );
    	}
    }
    
    /**
     * handler of ToggleButtonChanged event
     * @param  name the name of the widget
     * @param  buttonView the target Togglebutton     
     * @param  isChecked the toggleButton value     
     */
    public void onToggleButtonChanged( String name, ToggleButton buttonView, boolean isChecked ) {
    	resultData.putExtra( name, isChecked );
    	onConfigurationChanged();
    }    
    
    /**
     * handler of SpinnerChanged event
     * @param  name the name of the widget
     * @param  spinnerView the target Spinner     
     * @param  selected the Spinner value     
     */
    public void onSpinnerChanged( String name, Spinner spinnerView, int selected ) {
    	resultData.putExtra( name, selected );
    	onConfigurationChanged();
    }
    
    /**
     * Updates the configurations          
     */
    private void onConfigurationChanged() {
    	setResult( RESULT_OK, resultData );
    }
}
