package org.infomus.android.sensor_to_osc_template;

import java.util.HashMap;
import java.util.Map;

import org.infomus.android.sensor_to_osc_template.R;
import org.infomus.android.sensor_to_osc_template.OscSenderService.Status;

import android.os.Bundle;
import android.app.Activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.view.Menu;
import android.view.View;

import android.widget.TextView;


public class MainActivity extends Activity {
	private static final int REQUEST_CONFIGURATION_CODE = 1;
	private String networkAddress = "oscserver.infomus.org";
	private int networkPort = 10000;
	private int deviceIdentifier = 1;
	private int targetFPS = 1;
	boolean locked = false;
	private Map<String, Boolean> sensorsStatus = new HashMap<String, Boolean>();
	
	private OscSenderService.Status oscSenderServiceStatus = null;
	

	/**
     * OnCreate method overrides base class method
     * @param  savedInstanceState the saved activity's state    
     */ 
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        // NOTE: insert in the map all names of sensors (toggleButtons in the Configuration Activity)
        sensorsStatus.put(ConfigurationActivity.DISABLE_SCREEN_SAVER, false);
        sensorsStatus.put(ConfigurationActivity.ACCELEROMETER_STATUS, true);
        sensorsStatus.put(ConfigurationActivity.GYROSCOPE_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.PROXIMITY_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.LINEAR_ACCELERATION_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.GRAVITY_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.ROTATION_VECTOR_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.MAGNETIC_FIELD_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.PRESSURE_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.LIGHT_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.AMBIENT_TEMPERATURE_STATUS, false);
        sensorsStatus.put(ConfigurationActivity.HUMIDITY_STATUS, false);
    	
        loadConfiguration();       
        
    }

    /**
     * OnCreateOptionsMenu method overrides base class method
     * @param  menu the options menu    
     * @return always true
     */   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }
    
    /**
     * onActivityResult method overrides base class method, receives result data from a child activity 
     * @param  requestCode the request code returned by the child activity
     * @param  resultCode  the result code returned by the child activity (RESULT_OK is everything went well)
     * @param  data data returned by the child activity
     */
    @Override
    protected void onActivityResult (int requestCode, int resultCode, Intent data)
    {
    	super.onActivityResult(requestCode, resultCode, data);
    	
    	if( requestCode == REQUEST_CONFIGURATION_CODE ) {
	    	if( (data != null) && (resultCode == RESULT_OK) ) {
	    		networkAddress = data.getStringExtra(ConfigurationActivity.NETWORK_ADDRESS );
	            networkPort = data.getIntExtra(ConfigurationActivity.NETWORK_PORT, networkPort);
	            deviceIdentifier = data.getIntExtra(ConfigurationActivity.DEVICE_IDENTIFIER, deviceIdentifier );
	            targetFPS = data.getIntExtra(ConfigurationActivity.TARGET_FPS, targetFPS );
	            for (String name : sensorsStatus.keySet() ) {
	            	boolean oldStatus = sensorsStatus.get(name);
	            	boolean status = data.getBooleanExtra(name, oldStatus );
	            	if( oldStatus != status )
	            		sensorsStatus.put( name, status );
				}
	    	}
    	}
    }
    
    /**
     * onPause method invoked when the activity is paused, saves config data     
     */
    @Override
    protected void onPause()
    {
    	super.onPause();
    	
    	saveConfiguration();
    }
    
    /**
     * onResume method invoked when the activity is resumed, loads config data     
     */
    @Override
    protected void onResume()
    {
        super.onResume();
        updateStatus();
    }
    
    /**
     * configurationButtonClicked handler method, launches the configuration activity 
     * @param  view the view which raised the event     
     */
    public void configurationButtonClicked( View view ) {
    	if( locked )
    		return;
    	
    	Intent intent = new Intent(this, ConfigurationActivity.class);
    	
    	intent.putExtra(ConfigurationActivity.NETWORK_ADDRESS, networkAddress);
    	intent.putExtra(ConfigurationActivity.NETWORK_PORT, networkPort);
    	intent.putExtra(ConfigurationActivity.DEVICE_IDENTIFIER, deviceIdentifier);
    	intent.putExtra(ConfigurationActivity.TARGET_FPS, targetFPS);
    	for (String name : sensorsStatus.keySet() ) {
        	boolean status = sensorsStatus.get(name);
        	intent.putExtra(name, status);
		}
    	
        startActivityForResult(intent,REQUEST_CONFIGURATION_CODE);
    }
    
    /**
     * oscSenderControlButtonClicked handler method, launches the service control activity 
     * @param  view the view which raised the event     
     */
    public void oscSenderControlButtonClicked( View view ) {
    	if( locked )
    		return;
    	
    	Intent intent = new Intent(this, OscSenderControlActivity.class);
    	
    	intent.putExtra(ConfigurationActivity.NETWORK_ADDRESS, networkAddress);
    	intent.putExtra(ConfigurationActivity.NETWORK_PORT, networkPort);
    	intent.putExtra(ConfigurationActivity.DEVICE_IDENTIFIER, deviceIdentifier);
    	intent.putExtra(ConfigurationActivity.TARGET_FPS, targetFPS);
    	for (String name : sensorsStatus.keySet() ) {
        	boolean status = sensorsStatus.get(name);
        	intent.putExtra(name, status);
		}
    	
        startActivity(intent);
    }    
    
    /**
     * Save UI state changes to the savedInstanceState.
     * This bundle will be passed to onCreate if the process is
     * killed and restarted.
     * @param  savedInstanceState the data that will be saved 
     */
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
      super.onSaveInstanceState(savedInstanceState);
      
      savedInstanceState.putBoolean("Locked", locked);

    }
    
    /**
     * back button pressed handler     
     */  
    @Override
    public void onBackPressed() {    	
    	super.onBackPressed();    	
    }
        
    /**
     * loads saved data from the preferences.
     */
    private void loadConfiguration() {
    	SharedPreferences preferences = getPreferences(MODE_PRIVATE);
    	locked = preferences.getBoolean("Locked", locked);
    	networkAddress = preferences.getString(ConfigurationActivity.NETWORK_ADDRESS, networkAddress);
    	networkPort = preferences.getInt(ConfigurationActivity.NETWORK_PORT, networkPort);
    	deviceIdentifier = preferences.getInt(ConfigurationActivity.DEVICE_IDENTIFIER, deviceIdentifier);
    	targetFPS = preferences.getInt(ConfigurationActivity.TARGET_FPS, targetFPS );
    	for (String name : sensorsStatus.keySet() ) {
        	boolean oldStatus = sensorsStatus.get(name);
        	boolean status = preferences.getBoolean(name, oldStatus);
        	if( oldStatus != status )
        		sensorsStatus.put( name, status );
		}
    }
    
    /**
     * saves the configuration to the preferences.
     */
    private void saveConfiguration() {
    	SharedPreferences preferences = getPreferences(MODE_PRIVATE);
    	SharedPreferences.Editor editor = preferences.edit();
    	editor.putBoolean("Locked", locked);
    	editor.putString(ConfigurationActivity.NETWORK_ADDRESS, networkAddress);
    	editor.putInt(ConfigurationActivity.NETWORK_PORT, networkPort);
    	editor.putInt(ConfigurationActivity.DEVICE_IDENTIFIER, deviceIdentifier);
    	editor.putInt(ConfigurationActivity.TARGET_FPS, targetFPS);
    	for (String name : sensorsStatus.keySet() ) {
        	boolean status = sensorsStatus.get(name);
        	editor.putBoolean(name, status);
		}
    	
    	editor.commit();
    }
    
    /**
     * updates the service's status string on the main activity
     */
    private void updateStatus() {
    	boolean changed = false;
    	if( oscSenderServiceStatus == null )
    		changed = true;
    	else if( oscSenderServiceStatus != OscSenderService.getStatus() )
    		changed = true;
    	
    	if( changed ) {
    		oscSenderServiceStatus = OscSenderService.getStatus();
    		TextView statusText = (TextView)findViewById(R.id.textViewStatus);
    		switch( oscSenderServiceStatus ) {
				case Created:
					statusText.setText( "Service created" );
					break;
				case Idle:
					statusText.setText( "Service idle" );
					break;
				case Running:
					statusText.setText( "Service running" );
					break;
				default:
					statusText.setText( "*****" );
					break;
    		}
    	}
    	
    }
}
