package org.infomus.android.sensor_to_osc_template;

import org.infomus.android.sensor_to_osc_template.R;

import android.os.Bundle;
import android.app.Activity;
import android.content.Intent;
import android.view.Menu;
import android.view.View;

public class OscSenderControlActivity extends Activity {

	Bundle bundle = null;
	
	/**
     * OnCreate method overrides base class method
     * @param  savedInstanceState  the bundle passed by the main activity    
     */   
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_osc_sender_control);
        
        bundle = (Bundle)getIntent().getExtras().clone();
    }    
    
    /**
     * OnCreateOptionsMenu method overrides base class method
     * @param  menu the options menu    
     * @return always true
     */   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_osc_sender_control, menu);
        return true;
    }
    
    /**
     * handler of startpButtonClicked event
     * @param  view the widget which raised the event        
     */
    public void startButtonClicked( View view ) {
    	Intent service = new Intent(this, OscSenderService.class);
    	service.putExtras(bundle);
    	startService(service);
    }
    
    /**
     * handler of stopButtonClicked event
     * @param  view the widget which raised the event        
     */
    public void stopButtonClicked( View view ) {
    	Intent service = new Intent(this, OscSenderService.class);
    	
    	stopService(service);
    }
}
