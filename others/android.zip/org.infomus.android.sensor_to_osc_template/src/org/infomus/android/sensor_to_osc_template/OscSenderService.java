package org.infomus.android.sensor_to_osc_template;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;


import de.sciss.net.OSCMessage;
import de.sciss.net.OSCClient;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.widget.Toast;

/**
 * this class is a service
 * that will run in background and send data to the target pc
 */
public class OscSenderService extends Service {	
	/**
	 * the thread of the service	 
	 */
	private final class ServiceThread extends Thread  implements SensorEventListener {
		
		private SensorManager sensorManager = null;
		
		private Map<Integer, Sensor> sensors = new HashMap<Integer,Sensor>();

		private Handler handler = null;
		private OSCClient sender = null;
		private boolean started = false;
		private int deviceIdentifier = 1;		
		private int targetFPS = 1;
		
		/**
	     * wait for the thread to be started    
	     */
		public void waitStarted() {
			synchronized( this ) {
				if( started )
					return;
				while( true ) try {
					wait();
					if( started )
						return;
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}			
		}
		
		/**
	     * overload of the run function
	     */
		@Override
		public void run() {
			Looper.prepare();

			synchronized( this ) {
				handler = new Handler();
				started = true;
				notifyAll();
			}

		    Looper.loop();
          }
		
		/**
	     * quits the service stops the network,
	     * and releases the used sensors	          
	     */
		public void quit() {
			releaseAllSensors();
			releaseSensorManager();
			stopNetwork();
			synchronized( this ) {
				if( handler != null )
					handler.getLooper().quit();
			}
		}
		
		/**
	     * starts the network
	     * @param address the target machine's adress
	     * @param port the target pot	          
	     */
		public void startNetwork( final String address, final int port ) {
			if( (address == null) || address.isEmpty() )
				return;			
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							startNetworkAsync( address, port );
						}
					});
				}
			}
		}
		
		/**
	     * stops the network
	     */
		public void stopNetwork() {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							stopNetworkAsync();
						}
					});
				}
			}
		}
		
		/**
	     * configures a sensor
	     * @param enabled whether the sensor is enabled or not 
	     * @param sensorType the target sensor type (accelerometer,gyroscope,magnetic....)	          
	     */
		public void configureSensor( final boolean enabled, final int sensorType ) {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							if( enabled )
								enableSensorAsync( sensorType );
							else
								disableSensorAsync( sensorType );
						}
					});
				}
			}
		}
		
		/**
	     * configures the device identifier that will be used as prefix in the osc tag
	     * in order to manage data coming from different devices
	     * @param identifier the device identifier 
	     */
		public void configureDeviceIdentifier( final int identifier ) {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							configureDeviceIdentifierAsync( identifier );
						}
					});
				}
			}
		}
		
		/**
	     * configures the sensors fps
	     * @param fps the target fps 
	     */
		public void configureTargetFPS( final int fps ) {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							configureTargetFpsAsync( fps );
						}
					});
				}
			}
		}
		
		/**
	     * releases all the initialized sensors
	     */
		public void releaseAllSensors() {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							releaseAllSensorsAsync();
						}
					});
				}
			}
		}
		
		/**
	     * releases the sensors manager
	     */
		public void releaseSensorManager() {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							releaseSensorManagerAsync();
						}
					});
				}
			}
		}

		/**
	     * automatically added stub method
	     */
		public void onAccuracyChanged(Sensor sensor, int accuracy) {
			// TODO Auto-generated method stub			
		}
		
		/**
	     * rebinds all the sensors to the handler method
	     */
		public void rebindAllSensors() {
			synchronized( this ) {
				if( handler != null ) {
					handler.post( new Runnable () {
						public void run() {
							rebindAllSensorsAsync();
						}
					});
				}
			}
		}
		
		/**
	     * onSensorDataChanged event handler
	     * @param event the SensorEvent data. It contains info about the sensor that raised the event 
	     * and the measured data 
	     */
		public void onSensorChanged(SensorEvent event) {
			try {
				 /*
		         * MANAGE THE SENSOR EVENTS HERE!!
		         * */
	    		
	   	 	} catch (Exception e) {
	   	 		e.printStackTrace();
	   	 	}
		}
		
		/**
	     * sends an osc message containing a sensor measurements
	     * @param event	the SensorEvent data 
	     * @param oscTag	the tag that will be assignet to the message 
	     * @param numargs	the dimension of the measurement (usually it will be a number between 1 and 3)
	     */
		private void sendOscEvent( SensorEvent event, String oscTag, final int numArgs ) throws IOException {
			
			if( sender != null ) {
				Object args[] = new Object[numArgs];
				for( int i = 0; i < numArgs; ++i ) {
					args[ i ] = event.values[ i ];
				}
				
				OSCMessage msg;
	        	msg = new OSCMessage("/mobile" + deviceIdentifier + "/" + oscTag, args);
	        	
        		sender.send(msg);
        	}
		}
		
		/**
	     * starts the network
	     * @param address the target machine's adress
	     * @param port the target pot	          
	     */
		private void startNetworkAsync( String address, int port ) {
			try {
				stopNetworkAsync();
				sender = OSCClient.newUsing( OSCClient.UDP );
	        	sender.setTarget( new InetSocketAddress( address, port ));
				sender.start();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/**
	     * stops the network
	     */
		private void stopNetworkAsync() {
			try {
				if( sender != null ) {
					sender.stop();
					sender = null;
				}
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		/**
	     * get the sensor manager
	     */
		private void getSensorManagerAsync() {
			if( sensorManager == null )
				sensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		}
		
		/**
	     * releases the sensors manager
	     */
		private void releaseSensorManagerAsync() {
			if( sensorManager != null )
				sensorManager = null;
		}
		
		/**
	     * rebinds all the sensors to the handler method
	     */
		private void rebindAllSensorsAsync() {
			/*
			 * NOTE: the returnes keySet is modified while deleting items. So I cannot use a simple loop:
			 * for( Integer key: keys )
			 *   disableSensorAsync( key );
			 */
			Set<Integer> keys = sensors.keySet();
			if( keys == null )
				return;
			int types[] = new int[ keys.size() ];
			int index = 0;
			for( Integer key: keys )
				types[ index++ ] = key;
			for( int key: types ) {
				disableSensorAsync( key );
				enableSensorAsync( key );
			}
		}
		
		/**
	     * releases all the initialized sensors
	     */
		private void releaseAllSensorsAsync() {
			/*
			 * NOTE: the returnes keySet is modified while deleting items. So I cannot use a simple loop:
			 * for( Integer key: keys )
			 *   disableSensorAsync( key );
			 */
			Set<Integer> keys = sensors.keySet();
			if( keys == null )
				return;
			int types[] = new int[ keys.size() ];
			int index = 0;
			for( Integer key: keys )
				types[ index++ ] = key;
			for( int key: types ) {
				disableSensorAsync( key );
			}
		}

		/**
	     * enables a sensor
	     * @param sensorType the target sensor type (accelerometer,gyroscope,magnetic....)	          
	     */
		private void enableSensorAsync( int sensorType ) {
			Sensor sensor = sensors.get(sensorType);
			if( sensor == null ) {
				getSensorManagerAsync();
				sensor = sensorManager.getDefaultSensor(sensorType);
	        	if( sensor != null ) {
	        		sensorManager.registerListener(this, sensor, targetFPS, handler );
	        		sensors.put(sensorType, sensor);
	        	}
	        }
		}
		
		/**
	     * stops a sensor	     
	     * @param sensorType the target sensor type (accelerometer,gyroscope,magnetic....)	          
	     */
		private void disableSensorAsync( int sensorType ) {
			Sensor sensor = sensors.get(sensorType);
			if( sensor != null ) {
				getSensorManagerAsync();
	        	sensorManager.unregisterListener(this, sensor );
	        	sensors.remove(sensorType);
	        }
		}
		
		/**
	     * configures the device identifier that will be used as prefix in the osc tag
	     * in order to manage data coming from different devices
	     * @param identifier the device identifier 
	     */
		private void configureDeviceIdentifierAsync( int identifier ) {
			deviceIdentifier = identifier;
		}
		
		/**
	     * configures the sensors fps
	     * @param fps the target fps 
	     */
		private void configureTargetFpsAsync( int fps ) {
			targetFPS = fps;			
		}
	}
	
	/**
     * service's status enum     
     */
	public enum Status {
		Idle,
		Created,
		Running
	};

	static Status m_status = Status.Idle;
	private ServiceThread serviceThread = null;
	private PowerManager.WakeLock waveLock = null;
	private boolean m_disableScreenSaver = false;
	
	/**
     * BroadcastReceiver for handling ACTION_SCREEN_OFF.
     */	
    private BroadcastReceiver mReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            // Check action just to be on the safe side.
            if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF)) {
                // Unregisters the listener and registers it again.

            	rebindSensors();
            	deinitWaveLock();
            	initWaveLock();
            }
        }
    };
	
    /**
     * Constructor.
     */	
	public OscSenderService() {
		// TODO Auto-generated constructor stub
	}
	
	/**
     * gets the service's status
     * @return the service status
     */	
	static public Status getStatus() {
		return m_status;
	}
	
	/**
     * sets the service's status
     * @param status the service status
     */
	static private void setStatus( Status status ) {
		m_status = status;
	}

	/**
     * on service's create      
     */
	@Override
	public void onCreate() {
		Toast.makeText(this, "service creating", Toast.LENGTH_SHORT).show();
		
		serviceThread = new ServiceThread();
		serviceThread.start();
		serviceThread.waitStarted();
		
		setStatus( Status.Created );
	}

	/**
     * on service's startCommand      
     */
	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		int ret = START_STICKY;	// If we get killed, after returning from this method, restart
		
		if( getStatus() != Status.Running ) {
		    Toast.makeText(this, "service starting", Toast.LENGTH_SHORT).show();
	
		    setStatus( Status.Running );	    
		}
		
		m_disableScreenSaver = intent.getBooleanExtra( ConfigurationActivity.DISABLE_SCREEN_SAVER, false );
		initWaveLock();
				
	    serviceThread.startNetwork( intent.getStringExtra( ConfigurationActivity.NETWORK_ADDRESS ), intent.getIntExtra( ConfigurationActivity.NETWORK_PORT, 5000 ) );
		serviceThread.configureDeviceIdentifier( intent.getIntExtra( ConfigurationActivity.DEVICE_IDENTIFIER, 1 ) );
		serviceThread.configureTargetFPS( intent.getIntExtra( ConfigurationActivity.TARGET_FPS, 1 ) );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.ACCELEROMETER_STATUS, false ), Sensor.TYPE_ACCELEROMETER );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.GYROSCOPE_STATUS, false ), Sensor.TYPE_GYROSCOPE );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.PROXIMITY_STATUS, false ), Sensor.TYPE_PROXIMITY );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.LINEAR_ACCELERATION_STATUS, false ), Sensor.TYPE_LINEAR_ACCELERATION );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.GRAVITY_STATUS, false ), Sensor.TYPE_GRAVITY );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.ROTATION_VECTOR_STATUS, false ), Sensor.TYPE_ROTATION_VECTOR );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.MAGNETIC_FIELD_STATUS, false ), Sensor.TYPE_MAGNETIC_FIELD );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.PRESSURE_STATUS, false ), Sensor.TYPE_PRESSURE );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.LIGHT_STATUS, false ), Sensor.TYPE_LIGHT );
		serviceThread.configureSensor( intent.getBooleanExtra( ConfigurationActivity.AMBIENT_TEMPERATURE_STATUS, false ), Sensor.TYPE_TEMPERATURE );
		
		IntentFilter filter = new IntentFilter(Intent.ACTION_SCREEN_OFF);
        registerReceiver(mReceiver, filter);
        
	    return ret;
	}
	
	/**
     * gets the device name
     * @return the device name   
     */
	private String getDeviceName() {
	  String manufacturer = Build.MANUFACTURER;
	  String model = Build.MODEL;
	  if (model.startsWith(manufacturer)) {
	    return capitalize(model);
	  } else {
	    return capitalize(manufacturer) + " " + model;
	  }
	}

	/**
     * capitalizes a string 
     * @param s the target string
     * @return the capitalized string   
     */
	private String capitalize(String s) {
	  if (s == null || s.length() == 0) {
	    return "";
	  }
	  char first = s.charAt(0);
	  if (Character.isUpperCase(first)) {
	    return s;
	  } else {
	    return Character.toUpperCase(first) + s.substring(1);
	  }
	} 
	
	/**
     * configures the wake lock to let the service run even if 
     * the main activity is sleeping        
     */
	private void initWaveLock() {
		if( m_disableScreenSaver ) {
			if( waveLock == null ) {
				PowerManager manager = (PowerManager) getSystemService(Context.POWER_SERVICE);
				String deviceName = getDeviceName();
				if( deviceName.equals("Samsung GT-S6500"))
					waveLock = manager.newWakeLock(PowerManager.SCREEN_DIM_WAKE_LOCK | PowerManager.ACQUIRE_CAUSES_WAKEUP, "OscSenderWaveLock"); 	// this works on GalaxyMini2, but the screen remains on. Moreover, if the user pushes the on/off button and the screen goes off, but it is automatically turned on again. So there is a small break in data transmission, but transmission is resumed
				else
					waveLock = manager.newWakeLock(PowerManager.FULL_WAKE_LOCK, "OscSenderWaveLock"); // this works on all phones from CasaPaganini. Does not work with GalaxyMini2. Works with Nexus 4
				waveLock.acquire();
			}
		}
		else {
			if( waveLock != null ) {
				waveLock.release();
				waveLock = null;
			}
		}
	}
	
	/**
     * rebinds alle the active sensors
     */
	private void rebindSensors() {
		serviceThread.rebindAllSensors();		
	}
	
	/**
     * releases the wake lock        
     */
	private void deinitWaveLock() {
		if( waveLock != null ) {
			waveLock.release();
			waveLock = null;
		}
	}

	/**
     * stub method    
     */
	@Override
	public IBinder onBind(Intent arg0) {
		// TODO Auto-generated method stub
		return null;
	}
	
	/**
     * onDestroy called on service exit   
     */
	@Override
	public void onDestroy() {
		Toast.makeText(this, "service done", Toast.LENGTH_SHORT).show();
		
		unregisterReceiver(mReceiver);

		if( serviceThread != null ) {
			serviceThread.quit();
			try {
				serviceThread.join();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			serviceThread = null;
		}
		
		deinitWaveLock();
		
		setStatus(Status.Idle);
	}

}
