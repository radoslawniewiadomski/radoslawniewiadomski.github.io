/** Automatically generated file. DO NOT MODIFY */
package org.infomus.android.sensor_to_osc;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}